docker build -t decart/brat .
