#!/bin/bash

#cd /var/www/brat/brat-v1.3_Crunchy_Frog && /var/www/brat/brat-v1.3_Crunchy_Frog/install.sh <<EOD 
#$BRAT_USERNAME 
#$BRAT_PASSWORD 
#$BRAT_EMAIL
#EOD



#echo "Install complete. You can log in as: $BRAT_USERNAME"

#RUN cp -R /bratdata/jovyan/ /bratdata/salim/
#RUN cp -R /bratdata/jovyan/ /bratdata/brett/
#RUN cp -R /bratdata/jovyan/ /bratdata/junn/
#RUN cp -R /bratdata/jovyan/ /bratdata/annie/
#RUN cp -R /bratdata/jovyan/ /bratdata/beenish/
#RUN cp -R /bratdata/jovyan/ /bratdata/yun/
#RUN cp -R /bratdata/jovyan/ /bratdata/glory/
#RUN cp -R /bratdata/jovyan/ /bratdata/barbara/
#RUN cp -R /bratdata/jovyan/ /bratdata/peter/
#RUN cp -R /bratdata/jovyan/ /bratdata/sophia/
#RUN cp -R /bratdata/jovyan/ /bratdata/zhenyu/
#RUN cp -R /bratdata/jovyan/ /bratdata/sharif/
#RUN cp -R /bratdata/jovyan/ /bratdata/matthew/
#RUN cp -R /bratdata/jovyan/ /bratdata/dominik/
#RUN cp -R /bratdata/jovyan/ /bratdata/judy/
#RUN cp -R /bratdata/jovyan/ /bratdata/huaizhong/
#RUN cp -R /bratdata/jovyan/ /bratdata/vikas/
#RUN cp -R /bratdata/jovyan/ /bratdata/jose/
#RUN cp -R /bratdata/jovyan/ /bratdata/anindita/
#RUN cp -R /bratdata/jovyan/ /bratdata/christian/
#RUN cp -R /bratdata/jovyan/ /bratdata/partha/
#RUN cp -R /bratdata/jovyan/ /bratdata/carolyn/
#RUN cp -R /bratdata/jovyan/ /bratdata/sankar/
#RUN cp -R /bratdata/jovyan/ /bratdata/mamadou/
#RUN cp -R /bratdata/jovyan/ /bratdata/james/
#RUN cp -R /bratdata/jovyan/ /bratdata/melodee/
#RUN cp -R /bratdata/jovyan/ /bratdata/lorinette/
#RUN cp -R /bratdata/jovyan/ /bratdata/rumei/

chown -R www-data:www-data /bratdata
echo "copy customized config.py"
mv /bratdata/config.py /var/www/brat/brat-v1.3_Crunchy_Frog/config.py

mkdir /bratdata/config.py /var/www/brat/brat-v1.3_Crunchy_Frog/work
chown -R www-data:www-data /var/www/brat/brat-v1.3_Crunchy_Frog/server
chown -R www-data:www-data /var/www/brat/brat-v1.3_Crunchy_Frog/work

echo "copy annotation data to each user's directory"
cd /bratdata
for f in */; do
    echo "cp -R \"${f%}/.\" salim"
    cp -R "${f%}/." salim
    cp -R "${f%}/." brett
    cp -R "${f%}/." junn
    cp -R "${f%}/." annie
    cp -R "${f%}/." beenish
    cp -R "${f%}/." yun
    cp -R "${f%}/." glory
    cp -R "${f%}/." barbara
    cp -R "${f%}/." peter
    cp -R "${f%}/." sophia
    cp -R "${f%}/." zhenyu
    cp -R "${f%}/." sharif
    cp -R "${f%}/." matthew
    cp -R "${f%}/." dominik
    cp -R "${f%}/." judy
    cp -R "${f%}/." huaizhong
    cp -R "${f%}/." vikas
    cp -R "${f%}/." jose
    cp -R "${f%}/." anindita
    cp -R "${f%}/." christian
    cp -R "${f%}/." partha
    cp -R "${f%}/." carolyn
    cp -R "${f%}/." sankar
    cp -R "${f%}/." mamadou
    cp -R "${f%}/." james
    cp -R "${f%}/." melodee
    cp -R "${f%}/." lorinette
    cp -R "${f%}/." rumei
    cp -R "${f%}/." louis
    cp -R "${f%}/." kelly
    cp -R "${f%}/." wendy
    cp -R "${f%}/." jianlin
    cp -R "${f%}/." jeremiah
done

chown -hR www-data:www-data /var/www/brat/brat-v1.3_Crunchy_Frog/data/.
chmod -R 775 /var/www/brat/brat-v1.3_Crunchy_Frog/data/.
rm /bratdata/brat_setup.sh


exit 0
