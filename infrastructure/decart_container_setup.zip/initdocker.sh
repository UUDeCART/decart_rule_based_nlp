docker run --name=brat -d -p 8002:80 -v "$PWD"/bratdata:/bratdata decart/brat
